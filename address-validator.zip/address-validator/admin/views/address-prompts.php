
<?php
  echo '<div id="address-prompt" class="content active">
     <!-- first div -->
    <div class="form-content-subheading">
        <h3>What are address prompts?</h3>
    </div>
    <div class="form-content-box">
       <p class="address-des">This is the  1<sup>st</sup> line of defense against  shipping addresses eith mistakes. Address prompts either : (a) offer suggested corrections or (b) warn customers of invalid addresses when suggestions are not available. For example, it would be impossible to suggest  an alternative address for "123 Test Street".</p>
    </div>
    <form id="shop-add-prom">
        <!-- second div -->
        <div class="form-content-subheading">
          <h3>How does it work?</h3>
        </div>
        <div class="form-content-box form-box-wrapper">
            <div class="form-left-box" >
                <div class="box-subheading"><h3>The address prompts appear on the Thank You page <span class="text-italic">after </span>checkout.</h3></div>
                <div class="form-radio-options">
                    <div class="box-subheading"><h3>How do you want the prompts to appear?</h3></div>
                    <div class="radio-options-div">
                        <div>
                            <input class="form-radio" type="radio" value="Modal window" name="prompt_appear" id="modal">
                            <label for="modal">Modal window <span class="text-bold"> (recommended)</span></label>
                        </div>
                        <div>
                            <input class="form-radio" type="radio" value="Embedded below the map"  name="prompt_appear" id="map">
                            <label for="map">Embedded below the map</label>
                        </div>
                    </div>
                </div>
                <div class="form-para">
                    <p> Shipping addresses on the Shopify orders  will be updated automatically when customers select the suggested address or make changes via the <span class="text-italic"><a href="">address form</a></span> </p>
                    <p>You can see the app on the Thank You page by going through the entire checkout process, including the payment step.</p>
                    <p> Please contact us at <a href="">support@roboturk.co</a> if you have  <a href="">Shopify Plus</a> to incorporate the address prompts into the checkout. Otherwise, the app can only load  after checkout due to Shopify limitations.</p>
                </div>
            </div>
            <div class="form-right-box">
               <div></div>
            </div>
        </div> 
        
        <!-- third div -->
        <div class="form-div-wrapper">
            <div class="form-left-wrapper">
                <div class="form-content-subheading"><h3>US address validation options </h3></div>
                <div class="form-content-box">
                    <div class="form-checkbox-options">
                        <div><input class="form-checkbox" name="valid_opt_usps" id="USPS" type="checkbox"></div>
                        <div>
                           <label for="USPS">Do you only ship with USPS?</label>
                           <p class="form-faded-text">UPS/FedEx can ship to some addresses USPS cannot.This option determines the appropriate data sources to use for validation.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox-options">
                        <div><input class="form-checkbox" name="valid_opt_zipcode" id="ZIP+4" type="checkbox"></div>
                        <div>
                           <label for="ZIP+4">Do you want to ignore ZIP+4 codes?</label>
                           <p class="form-faded-text">ZIP+4 codes are the last 4 digits of a 9-digit zipcode. While not required by USPS, these can help ensure the fastest  and  most accurate  delivery possible.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox-options">
                        <div><input class="form-checkbox"  name="valid_opt_sep_apt" id="apt" type="checkbox"></div>
                        <div>
                           <label for="apt">Do you need to separate the street address from the apt #? </label>
                           <p class="form-faded-text">USPS formatting dictates  that the apartment #  follow  the street address on the  same field. However, some 3PLs require the two components in separate fields (address_1 and  address_2). </p>
                        </div>
                    </div> 
                </div>
            </div>
            <div class="form-right-wrapper">
                <div class="form-content-subheading"><h3>Advanced options</h3></div>
                <div class="form-content-box">
                    <div class="form-checkbox-options">
                        <div><input class="form-checkbox" name="adv_opt_proper_format" id="add-formatting" type="checkbox"></div>
                        <div>
                           <label for="add-formatting">Do you want to ignore proper address formatting?</label>
                           <p class="form-faded-text">If enabled, no suggested changes will be shown if the only discrepancies are merely formatting, capitalizations or abbreviations. For exampple, "20 main st" would be equivalent  to "20 Main Street" and no suggested changes will be shown . While proper formatting is not required  for accurate delivery , it may be useful for other purposes.</p>
                        </div>
                    </div>
                    <div>
                        <p>Specify list of keywords to skip address validation</p>
                        <p class="form-faded-text">This allows you to bypass the validation process for test or in-store  pickup orders. Whenever  the  address_1, address_2, or company  fields contains any of the keywords, the address validation will be skipped. The keywords are not  case sensitive.</p>
                        <div id="output"></div>
                        // <div class="form-input">
                        //    <input class="form-input" id="textInput" name="keyword_skip_add_valid" id="keyword_skip_add_valid" type="text"><button class="form-btn" onclick="addKeyword()">Add</button>
                        // </div>
                    </div>
                    <div class="form-input-box form-border-top">
                        <label for="wait-time">How much time does the customer have to update the order after the checkout is complete?</label>
                        <select class="form-select" name="time_to_update_order" id="wait-time" >
                           <option value="2 minutes">2 minutes</option>
                           <option value="5 minutes">5 minutes</option>
                           <option value="10 minutes">10 minutes</option>
                           <option value="30 minutes">30 minutes</option>
                           <option value="1 hours">1 hours</option>
                           <option value="2 hours">2 hours</option>
                           <option value="3 hours">3 hours</option>
                           <option value="6 hours">6 hours</option>
                           <option value="12 hours">12 hours</option>
                           <option value="1 day">1 day</option>
                           <option value="2 days">2 days</option>
                           <option value="3 days">3 days</option>
                           <option value="1 week">1 week</option>
                        </select>
                        <span class="dropdown-icon-1" onclick="toggleDropdown()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrows-expand" viewBox="0 0 16 16">
                           <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 8M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2M8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10"/>
                        </svg></span>
                    </div>
                    <div class="form-input-box form-border-top">
                      <label for=""> Need to pause the app while you configure  the settings?</label>
                      <button class="form-pause-btn" name="form-pause-btn" class="form-btn">Pause app</button>
                    </div>
                </div> 
            </div>
        </div>
    </form>
   



   <!-- fourth div -->
    <form id="shop-gen-customization">
        <div class="form-content-subheading"><h3>General customizations</h3></div>
        <div class="form-div-wrapper form-content-box">
            <div class="form-left-wrapper">
                <div class="form-customization">
                    <div class="form-customization-box">
                        <div class="color-pick color-border">
                           <input name="trim_color" type="color" value="#ffffff" />
                        </div>
                        <p>Trim</p>
                    </div>
                    <div class="form-customization-box">
                        <div class="color-pick color-border">
                           <input name="border_color" type="color" value="#ffffff" />
                        </div>
                        <p>Border</p>
                    </div>
                    <div class="form-customization-box ">
                        <div class="color-pick color-border">
                           <input name="bg_color" type="color" value="#ffffff" />
                        </div>
                        <p>Background</p>
                    </div>
                    <div class="form-customization-box text-circle">
                        <div class="color-pick">
                            <input name="text_color" type="color" value="#000000" />
                        </div>
                        <p>Text</p>
                    </div>
                    <div class="form-customization-box hover-circle">
                        <div class="color-pick">
                           <input name="hover_color" type="color" value="#84afff" />
                        </div>
                        <p>Hover</p>
                    </div>
                    <div class="form-customization-box button-bcg-circle">
                        <div class="color-pick">
                            <input name="btn_bg_color" type="color" value="#367eff" />
                        </div>
                        <p>Button Background</p>
                    </div>
                    <div class="form-customization-box button-border-circle">
                        <div class="color-pick">
                           <input type="color" value="#367eff" />
                        </div>
                        <p>Button Border</p>
                    </div>
                    <div class="form-customization-box">
                        <div class="color-pick color-border">
                           <input name="btn_text_color" type="color" value="#ffffff" />
                        </div>
                        <p>Button Text</p>
                    </div>
                </div>
                <div class="form-div-box">
                    <div>
                        <p>Corner style</p>
                        <div>
                           <input type="radio" name="corner_style" value="Rounded corners" id="rounded">
                           <label for="rounded">Rounded corners</label>
                        </div>
                        <div>
                           <input type="radio" name="corner_style" value="Square corners" id="square">
                           <label for="square">Square corners</label>
                        </div>
                    </div>
                    <div class="border-width-option">
                        <label for="border-width">Border width</label>
                        <div class="dropdown-container">
                            <select name="border_width" id="border-width" onclick="toggleDropdown()">
                                <option value="0.0px">0.0px</option>
                                <option value="0.5px">0.5px</option>
                                <option value="1.0px">1.0px</option>
                                <option value="1.5px">1.5px</option>
                                <option value="2.0px">2.0px</option>
                                <option value="2.5px">2.5px</option>
                                <option value="3.0px">3.0px</option>
                                <option value="3.5px">3.5px</option>
                                <option value="4.0px">4.0px</option>
                                <option value="4.5px">4.5px</option>
                                <option value="5.0px">5.0px</option>
                            </select>
                            <span class="dropdown-icon-2" onclick="toggleDropdown()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrows-expand" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 8M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2M8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10"/>
                            </svg></span>
                       </div>
                    </div>
                </div>
                <div class="form-checkbox-option">
                    <div><input id="outline" name="outline_focus_ele" type="checkbox"></div>
                    <div>
                        <label for="outline">Outline focused elements ?</label>
                        <p class="form-faded-text">UPS/FedEx can ship to some addresses USPS cannot.This option determines the appropriate data sources to use for validation.</p>
                    </div>
                </div> 
                <div class="form-checkbox-option">
                    <div><input type="checkbox" name="hide_msg" id="hide-messages"></div>
                    <div>
                      <label for="hide-messages">Do you want to hide messages when a customer specifies a correct address?</label>
                    </div>
                </div> 
                <div class="form-input-content">
                   <label for="close-btn">Close button on prompts</label>
                   <input type="text" name="close_btn_prompts" id="close-btn" value="Close">
                </div>
                <div class="form-input-content">
                    <p>Message  when a correct address is detected</p>
                    <input type="text" name="msg_correct_addr" value="Thanks for specifying  an accurate shipping address !">
                </div>
                <div class="form-input-content">
                    <p>Input custom CSS </p>
                    <textarea id="ta-123" name="input_custom_css"  rows="10" 
                    >Example: 
          #addressValidatoBox{
          font-family:Arial, Helvetica , sans-serif;
          color: #32CD32;
          } </textarea>
                </div>
            </div>
            <div class="form-right-wrapper">
                <div class="form-background">
                    <p>Message when a correct address is detected</p>
                    <div class="form-content-box form-gratitude">
                       Thanks for specifying an accurate  shipping address!
                    </div>
                </div>
            </div>
        </div>    
    </form>








    <!-- fifth-div -->
    <form id="shop-suggested-cor-prompts">
        <div class="form-content-subheading">
           <h3>Customize suggested corrections prompt</h3>
        </div>
        <div class="form-content-box form-div-wrapper">
            <div class="form-left-wrapper">
                <div class="form-option">
                    <div class="form-checkbox">
                        <div><input name="show_exit_btn" type="checkbox" id="exit-btn"></div>
                        <div>
                           <label for="exit-btn">Show exit button ?</label>
                           <p class="form-faded-text">If enabled, customers can exit of the prompt without confirming the original address or using the suggested corrections.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox">
                        <div><input name="show_accept_btn" type="checkbox" id="accept-btn"></div>
                        <div>
                            <label for="accept-btn">Show accept button?</label>
                            <p class="form-faded-text">If enabled, customers can accept the corrected address via the button or clicking  on the suggested address.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox">
                        <div><input name="show_devider" type="checkbox" id="divider-btn"></div>
                        <div>
                            <label for="divider-btn">Show divider?</label>
                            <p class="form-faded-text">UPS/FedEx can ship to some addresses USPS cannot.This option determines the appropriate data sources to use for validation.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox">
                        <div><input name="show_opt_borders" type="checkbox" id="border-btn"></div>
                        <div>
                           <label for="border-btn">Show option borders?</label>
                           <p class="form-faded-text">If enabled, borders will be added to the address options.</p>
                        </div>
                    </div> 
                    <div class="form-checkbox">
                        <div><input name="show_opt_btn" type="checkbox" id="option-btn"></div>
                        <div>
                            <label for="option-btn">Show option buttons? </label>
                            <p class="form-faded-text">If enabled, buttons will be added next to the address options.</p>
                        </div>
                    </div> 
                </div>
                <div class="form-option form-gap">
                    <div class="form-circle-div">
                        <div class="color-pick color-border">
                           <input name="highlight_changes_color" type="color" value="#367eff" />
                        </div>
                        <p>Highlight Changes</p>
                    </div>
                    <div class="form-circle-div">
                        <div class="color-pick color-border">
                            <input name="opt_border_color" type="color" value="#367eff" />
                        </div>
                        <p>Option border</p>
                    </div>
                </div>
                <div class="form-option-label">
                   <p>Title</p>
                   <input type="text" name="title" value="Please select shipping address">
                </div>
                <div class="form-option-label">
                   <p>Subtitle</p>
                   <input type="text" name="subtitle" value="To ensure prompt and accurate delivery, we suggest a modified shipping address.">
                </div>
                <div class="form-option-label">
                   <p>Suggested address label</p>
                   <input type="text" name="suggested_addr_label" id="" value="Suggested address:">
                </div>
                <div class="form-option-label">
                   <p>Original address label</p>
                   <input type="text" name="original_addr_label" id="" value="Original address:">
                </div>
                <div class="form-option-label">
                   <p>Original address option button</p>
                   <input type="text" name="original_addr_opt_btn" id="" value="Keep Original">
                </div>
                <div class="form-option-label">
                   <p>Accept changes button label</p>
                   <input type="text" name="acpt_changes_btn_label" id="" value="Accept changes">
                </div>
                <div class="form-option-label">
                   <p>Suggested address option selected</p>
                   <input type="text" name="suggested_addr_opt_sel" id="" value="Your shipping address has been updated!">
                </div>
                <div class="form-option-label">
                   <p>Original address option selected</p>
                   <input type="text" name="original_addr_opt_sel" id="" value="Thanks for confirming your shipping address!">
                </div>
            </div>
            <div class="form-right-wrapper">
                <div class="background-faded">
                    <div class="form-address-subheading"> <h4>Suggested corrections prompt</h4></div>
                    <div class="form-address-wrapper">
                        <h2>Please select shipping address </h2>
                        <p>To ensure prompt and accurate delivery, we suggest a modified shipping address.</p>
                        <div>
                            <p class="address-label">Suggested address</p>
                            <span>
                              <span class="address-show">400 Howard St</span>
                              <span class="address-show">San Francisco</span> , CA 94105 - <span class="address-show"> 2618 </span>
                            </span>
                        </div>
                        <div>
                            <p class="address-label">Original address</p>
                            <span class="original-address">
                               400 Howard St
                               San Francisco, CA 94105 - 2618
                            </span>
                        </div> 
                        <div class="address-btn">
                           <button class="form-btn">Close</button>
                           <button class="form-btn">Accept changes</button>
                        </div>
                    </div>
                    <div class="form-address-subheading"><h4>Suggested address option selected</h4></div>
                    <div class="form-address-wrapper form-content-align">
                        Your shipping address has been updated!
                    </div>
                    <div class="form-address-subheading"><h4>Original address option selected</h4></div>
                    <div class="form-address-wrapper form-content-align">Thanks for confirming your shipping address!</div>
                </div>
            </div>
        </div>  
    </form>






    <!-- sixth div -->
    <form id="shop-unveri-addr-prompts" >
        <div class="form-content-subheading">
           <h3>Customize unverfiable addresses prompts</h3>
        </div>
        <div class="form-content-box form-div-wrapper">
            <div class="form-left-wrapper">
                <div class="form-option-label">
                   <p>Prompt when an inaccurate address is detected</p>
                   <input type="text" name="prompts_inacc_addr" value="Is the shipping address correct?">
                </div>
                <div class="form-option-label">
                   <p>Prompt when the apt # is missing</p>
                   <input type="text" name="prompts_apt_miss" id="" value="Did you specify the correct apt/suite/unit?">
                </div>
                <div class="form-option-label">
                    <p>Update address button label</p>
                    <input type="text" name="addr_btn_label" id="" value="Update address">
                </div>
                <div class="form-option-label">
                   <p>Proceed button label</p>
                   <input type="text" name="proceed_btn_label" id="" value="Proceed">
                </div>
                <div class="form-option-label">
                   <p>Button to open address correction from</p>
                   <input type="text" name="btn_open_addr" id="" value="Update or confirm address">
                </div>
            </div>
            <div class="form-right-wrapper">
                <div class="form-address-subheading"> <h4>Prompt when an inaccurate address is detected</h4></div>
                <div class="form-content-box form-content-align">
                    <p>Is the shipping address correct?</p>
                    <div>
                        <div class="non-existent-add">
                            <span>
                              Nonexistent Address
                              San Francisco, CA, 94105
                            </span>
                        </div>
                    </div>
                    <!-- <input type="text"> -->
                    <div class="address-btn">
                      <button class="form-btn">Close</button>
                      <button class="form-btn">Update or confirm address</button>
                    </div>
                </div>
                <div class="form-address-subheading"><h4>Prompt when the apt # is missing</h4></div>
                <div class="form-content-box form-content-align">
                    <p>Did you specify the correct apt/suite/unit?  </p>
                    <div>
                        <div class="non-existent-add">
                            <span>
                              Apartment Building address
                              San Francisco, CA, 94105
                            </span>
                        </div>
                    </div>
                    <div class="address-btn">
                        <button class="form-btn">Close</button>
                        <button class="form-btn">Update or confirm address</button>
                    </div>
                </div>
            </div>
        </div> 
    </form>
    <div id="success-message"></div>  
    <div id="failure-message"></div>
</div>';
  
?>
<?php 
  define("AV_PLUGIN_URL_IMAGE", plugins_url());
  echo '<form id="api-settings">
    <div id="api-settings">
        <div class="validator-common-prompt">
            <div class="validator-prompt-img">    
               <img src="' . AV_PLUGIN_URL_IMAGE. '/address-validator/assets/images/api-setting-prompts.svg' . '" alt="API Settings Prompts">
            </div>
            <div class="validator-prompt-content">
               <h2>What are these forms?</h2>
               <p>These forms allow customers to update the shipping address after checkout when they proceed with addresses that cannot be validated. They are accessible via the Thank You page after checkout or on the email notifications.</p>
            </div>
        </div>
        <div class="validation-rules-heading">
           <h3>Google Address Validator API Key</h3>
        </div>
        <div class="api-classes api-not-connect">
            <div class="api-google-key-bg">
                <div class="api-google-address">
                    <div class="aga-color">
                        <h2>Put google api key to connect address validator</h2>
                        <p>This API allow us to integrate your website checkout with our advanced customization.</p>
                        
                        <div class="api-adg-input">
                           <input type="text" id="gapikey" placeholder="Write google api key here...">
                        </div>
                        <div class="api-notice-bar">
                            <p>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                   <path d="M9.99986 6C10.4141 6.00001 10.7499 6.3358 10.7498 6.75001L10.7498 10.25C10.7498 10.6642 10.414 11 9.99978 11C9.58556 11 9.24978 10.6642 9.24979 10.25L9.24985 6.74999C9.24985 6.33577 9.58565 5.99999 9.99986 6Z" fill="#EF4D2F"></path>
                                   <path d="M10.9998 13C10.9998 13.5523 10.5521 14 9.99985 14C9.44756 14 8.99985 13.5523 8.99985 13C8.99985 12.4477 9.44756 12 9.99985 12C10.5521 12 10.9998 12.4477 10.9998 13Z" fill="#EF4D2F"></path>
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M11.2373 3.17663C10.5539 2.49321 9.44583 2.49321 8.76241 3.17663L3.17663 8.76241C2.49321 9.44583 2.49321 10.5539 3.17663 11.2373L8.76241 16.8231C9.44583 17.5065 10.5539 17.5065 11.2373 16.8231L16.8231 11.2373C17.5065 10.5539 17.5065 9.44583 16.8231 8.76241L11.2373 3.17663ZM9.82307 4.23729C9.9207 4.13965 10.079 4.13966 10.1766 4.23729L15.7624 9.82307C15.86 9.9207 15.86 10.079 15.7624 10.1766L10.1766 15.7624C10.079 15.86 9.9207 15.86 9.82307 15.7624L4.23729 10.1766C4.13965 10.079 4.13966 9.9207 4.23729 9.82307L9.82307 4.23729Z" fill="#EF4D2F"></path>
                                </svg>
                                API not connected. <span> <a href="#"> See how it works?</a></span>
                            </p>
                            <div class="api-adg-cross" onclick="removeParentClass(this)">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                   <path d="M12.7197 13.7803C13.0126 14.0732 13.4874 14.0732 13.7803 13.7803C14.0732 13.4874 14.0732 13.0126 13.7803 12.7197L11.0607 10L13.7803 7.28033C14.0732 6.98744 14.0732 6.51256 13.7803 6.21967C13.4874 5.92678 13.0126 5.92678 12.7197 6.21967L10 8.93934L7.28033 6.21967C6.98744 5.92678 6.51256 5.92678 6.21967 6.21967C5.92678 6.51256 5.92678 6.98744 6.21967 7.28033L8.93934 10L6.21967 12.7197C5.92678 13.0126 5.92678 13.4874 6.21967 13.7803C6.51256 14.0732 6.98744 14.0732 7.28033 13.7803L10 11.0607L12.7197 13.7803Z" fill="#8E1F0B"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="api-google-map">
                    <div class="agm-color">
                        <h2>API Status</h2>
                        <div class="api-map-btn">
                           <img class="map-img" src="' . AV_PLUGIN_URL_IMAGE. '/address-validator/assets/images/api-setting-map.png' . '" alt="map-img">
                           <button type="button" class="btn img-btn">API not connected</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div id="success-message"></div>  
<div id="failure-message"></div>'
?>
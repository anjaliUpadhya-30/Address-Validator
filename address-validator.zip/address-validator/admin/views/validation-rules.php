<?php
  echo 
    '<form id = "validation-rules">
        <div id="validation-rules" class="content">
            <div class="form-content-subheading">
                <h3>What are these address rules?</h3>
            </div>
            <div class="form-content-box">
                 This allows you to prompt customers for alternative addresses when indeliverable ones are detected (ie PO Boxes or addresses with non-Latin characters)
            </div>
            <div class="form-content-subheading">
                <h3>Rules</h3>
            </div>
            <div class="form-content-box form-div-wrapper">
                <div class="validation-wrapper">
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox"  class="validation-addr-check" name="en_gen_msg" id="gen-msg"></div>
                            <div>
                                <label for="gen-msg"><span class="text-bold">Enable this option in display a general massage above the address form.</span></label>
                                <p class="form-faded-text">You may want to add a message like "Please double check the shipping address to ensure prompt delivery"</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="custom-msg">Customize message:</label>
                            <input type="text" class="validation-rules-input" name="cus_gen_msg" id="custom-msg" >
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option form-hidden-div">
                            <div class="form-hidden-option" onclick="toggleCheckboxAndContentFirst()" >
                                <div><input type="checkbox" name="en_po_boxes" class="validation-addr-check" id="po-boxes"></div>
                                <div>
                                    <label for="po-boxes">Enable this option if you cannot ship to <span class="text-bold"> PO Boxes</span></label>
                                    <p class="form-faded-text">Couriers like FedEx and UPS cannot ship to PO Boxes </p>
                                </div>
                            </div>
                            <div id="PO-Boxes" class="hidden-input">
                                <label for="">What is the scope of these PO Box alerts?</label>
                                <select name="" id="" >
                               <option value="All countries">All countries</option>
                               <option value="New Zealand only">New Zealand only</option>
                               <option value="Australia only">Australia only</option>
                               <option value="US only">US only</option>
                               <option value="Non-US countries only">Non-US countries only</option>
                                </select>
                                <span class="dropdown-icon-3"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrows-expand" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 8M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2M8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10"/>
                                </svg></span>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="custom-warn">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_po"  class="validation-rules-input" id="custom-warn" value="We cannot deliver to PO Box. Please provide a valid street address.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_usps_gopost" id="USPS-gopost" class="validation-addr-check"></div>
                            <div>
                                <label for="USPS-gopost">Enable this option if you cannot ship to <span class="text-bold"> USPS gopost</span></label>
                                <p class="form-faded-text">Couriers like FedEx and UPS cannot ship to USPS gopost </p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="USPS-restrict">Customize warning message:</label>
                            <input type="text" name="cus_warn_msg_usps"  class="validation-rules-input" id="USPS-restrict"  value="We cannot deliver to USPS gopost addresses">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_high_con_route" class="validation-addr-check" id="highway-contract"></div>
                            <div>
                               <label for="highway-contract">Enable this option if you cannot ship to <span class="text-bold">Highway Contract Route</span></label>
                               <p class="form-faded-text">Highway Contract Routes are used in rural locations and some  couriers cannot  deliver to them. </p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="highway-route">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_high" class="validation-rules-input" id="highway-route" value="We cannot deliver to  Highway Contract  Routes">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_pvt_mailbox" id="private-mailbox" class="validation-addr-check"></div>
                            <div>
                              <label for="private-mailbox">Enable this option if you cannot ship to <span class="text-bold">Private Mailboxes</span></label>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="pvt-mail">Customize warning message:</label>
                            <input type="text" name="cus_warn_msg_pvt" class="validation-rules-input" id="pvt-mail" value="We cannot deliver to a private mailbox . Please  provide  a valid street addresses.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_parcel_locker" id="parcel-locker" class="validation-addr-check"></div>
                            <div>
                              <label for="parcel-locker">Enable this option if you cannot ship to <span class="text-bold">Parcel Lockers or Parcel Collects</span></label>
                               <p class="form-faded-text">This may be applicable  if you  ship to Australia and/or New Zealand</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="par-lock">Customize warning message:</label>
                            <input type="text" name="cus_warn_msg_parcel" class="validation-rules-input" id="par-lock" value="We cannot deliver to a Parcel Locker . Please  provide  a valid street addresses.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_dhl_pack" id="DHL-pack" class="validation-addr-check"></div>
                            <div>
                               <label for="DHL-pack">Enable this option if you cannot ship to <span class="text-bold">DHL Packstations</span></label>
                               <p class="form-faded-text">This may be applicable  if you  ship to Austria and/or Germany.</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="packst">Customize warning message:</label>
                            <input type="text" name="cus_warn_msg_dhl" class="validation-rules-input" id="packst" value="We cannot deliver to a Packstations. Please  provide  a valid street addresses.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">   
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_dhl_pack_addr" id="packstation" class="validation-addr-check"></div>
                            <div>
                               <label for="packstation">Enable this option if you cannot ship to <span class="text-bold">DHL Packstation addresses with the station # on the same line as the term "Packstation"</span></label>
                               <p class="form-faded-text">Some 3PLs require the term  "Packstation"  to be on a different  line than the Packstation #</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="pack-suit">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_dhl_pack" class="validation-rules-input" id="pack-suit" value="Please specify the Packststaions # on the apt/suite line.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_addr_miss_house" class="validation-addr-check"  id="missing-home"></div>
                            <div>
                                <label for="missing-home">Enable this option if you cannot ship to <span class="text-bold">addresses with  missing  house #</span></label>     
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="street-no">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_addr_miss_house"  class="validation-rules-input" id="street-no" value="Please specify a street number.">
                       </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_addr_miss_str" class="validation-addr-check" id="missing-street"></div>
                            <div>
                              <label for="missing-street">Enable this option if you cannot ship to <span class="text-bold">addresses with  missing street names</span></label>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="street-name">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_addr_miss_str" class="validation-rules-input" id="street-name" value="Please specify a street name.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option form-hidden-div">
                            <div class="form-hidden-option" onclick="toggleCheckboxAndContentSecond()">
                                <div><input type="checkbox"  name="en_extra_long_addr"  class="validation-addr-check" id="long-address"></div>
                                <div>
                                   <label for="long-address">Enable this option if you cannot ship to <span class="text-bold">extra long addresses</span></label>
                                   <p class="form-faded-text">Some 3PLs and couriers have character limits on the address_1 ,  address_2, city and company fields.</p>
                                </div>
                            </div>
                            <div id="max-chara-limit" class="hidden-input">
                                <label for="chara-limit">What is the maximum character limit?</label>
                                <select name="chara-limit" id="chara-limit" >
                                   <option value="10">10</option>
                                   <option value="15">15</option>
                                   <option value="20">20</option>
                                   <option value="25">25</option>
                                   <option value="30">30</option>
                                   <option value="35">35</option>
                                   <option value="40">40</option>
                                   <option value="45">45</option>
                                   <option value="50">50</option>
                                   <option value="55">55</option>
                                   <option value="60">60</option>
                                </select>
                                <span class="dropdown-icon-3"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrows-expand" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 8M7.646.146a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 1.707V5.5a.5.5 0 0 1-1 0V1.707L6.354 2.854a.5.5 0 1 1-.708-.708l2-2M8 10a.5.5 0 0 1 .5.5v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 14.293V10.5A.5.5 0 0 1 8 10"/>
                                </svg></span>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="long-add">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_extra_long_addr" class="validation-rules-input" id="long-add" value="Address is too long - please limit to  40 characters">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_addr_emojis" id="emoji-address" class="validation-addr-check"></div>
                            <div>
                                <label for="emoji-address">Enable this option if you cannot ship to <span class="text-bold">addresses with emojis</span></label>
                                <p class="form-faded-text">Some 3PLs and couriers cannot parse emojis. This rule  is applied  to the address_1 , address_2, city and company fields.</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                          <label for="no-emoji">Customize warning message:</label>
                          <input type="text" name="cus_warn_msg_addr_emojis" class="validation-rules-input" id="no-emoji" value="No emojis allowed.">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                           <div><input type="checkbox" name="en_addr_nlc_euro" id="latin-address" class="validation-addr-check"></div>
                           <div>
                            <label for="latin-address">Enable this option if you cannot ship to <span class="text-bold">addresses with non-latin characters . Accented characters like a, e or o are not allowed . Do not use option if you ship to  European  addresses</span></label>
                            <p class="form-faded-text">Some 3PLs and couriers cannot parse non-latin  characters . Do not use this option if you ship  to European  addresses. This rule is applied  to the address_1, address_2, city  and company  fields. </p>
                           </div>
                        </div> 
                        <div class="form-validation-input">
                          <label for="latin-chara">Customize warning message:</label>
                          <input type="text" name="cus_warn_msg_nlc_euro" class="validation-rules-input" id="latin-chara" value="Please specify address with Latin characters only .">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_addr_nlc_acc" id="non-latin-address" class="validation-addr-check"></div>
                            <div>
                               <label for="non-latin-address">Enable this option if you cannot ship to <span class="text-bold">addresses with non-latin characters . Accented characters like a, e or o are  allowed . </span></label>
                               <p class="form-faded-text">Some 3PLs and couriers cannot parse non-latin  characters .This rule is applied  to the address_1, address_2, city  and company  fields.</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                            <label for="latin-chara">Customize warning message:</label>
                            <input type="text" name="cus_warn_msg_nlc_acc" class="validation-rules-input" id="latin-chara" value="Please  specify  address with Latin characters only . Accented  characters allowed">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_ship_cont_state" id="city-restricted" class="validation-addr-check"></div>
                            <div>
                               <label for="city-restricted">Enable this option if you cannot ship to <span class="text-bold">Alaska, Guam, Hawaii or Puerto Rico.</span></label>
                               <p class="form-faded-text">Some couriers  cannot be noncontiguous US states (Alaska,Guam,Hawaii or Puerto Rico).</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="cont-states">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_cont_state" class="validation-rules-input" id="cont-states" value="We only ship to contiguous states. ">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_mili_addr" class="validation-addr-check" id="military-address"></div>
                            <div>
                                <label for="military-address">Enable this option if you cannot ship to  <span class="text-bold">Military addresses</span></label>
                                <p class="form-faded-text">Some couriers  cannot be US military addresses (Armed Forces Americas , Armed  Forces Europe, Armed Forces Pacific)</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="mili-add">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_mili_addr" class="validation-rules-input" id="mili-add" value="We do not ship to military addresses">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_non_numeric_postalcode" id="postal-code" class="validation-addr-check"></div>
                            <div>
                               <label for="postal-code">Enable this option if you cannot ship to <span class="text-bold"> non-numeric  postal codes. Do not use this option if you ship to countries  outside  of the US</span></label>
                               <p class="form-faded-text">For example, this  may be applicable  if you only  ship to the US  where  the zip code is purely numeric</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                          <label for="post-num">Customize warning message:</label>
                          <input type="text" name="cus_warn_msg_non_numeric_postalcode" class="validation-rules-input" id="post-num" value="Only numbers allowed in the post code field">
                        </div>
                    </div>
                    <div class="form-validation-wrapper">
                        <div class="form-select-option">
                            <div><input type="checkbox" name="en_rural_addr" id="rural-address" class="validation-addr-check"></div>
                            <div>
                               <label for="rural-address">Enable this option if you cannot ship to <span class="text-bold">rural addresses in New Zealand</span></label>
                               <p class="form-faded-text">UPS/FedEx can ship to some addresses USPS cannot.This option determines the appropriate data sources to use for validation.</p>
                            </div>
                        </div> 
                        <div class="form-validation-input">
                           <label for="alt-add">Customize warning message:</label>
                           <input type="text" name="cus_warn_msg_rural_addr" class="validation-rules-input" id="alt-add" value="We cannot deliver to rural  addresses. Please provide  an alternative  address.">
                        </div>
                    </div>
                </div>
            </div>   
        </div>
   </form>
   <div id="success-message" ></div>  

'

;
?>
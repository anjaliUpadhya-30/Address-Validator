




// var popupForm = `<section id="popUpAddressForm"><div class="scroll-right-prompt-popUpform"><h5>Suggested corrected prompts</h5><div class="scroll-rshiping-adrs-bg"><div class="scroll-rshiping-adrs">
// <div class="sadr-accurate"><div><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none"><path d="M3.33325 8.33331L14.9999 3.33331L24.9999 8.33331L35.5049 3.83115C35.9281 3.64985 36.4179 3.8458 36.5993 4.26883C36.6436 4.37256 36.6666 4.48425 36.6666 4.5971V31.6666L24.9999 36.6666L14.9999 31.6666L4.49485 36.1688C4.07182 36.3501 3.58194 36.1541 3.40064 35.7311C3.35617 35.6275 3.33325 35.5156 3.33325 35.4028V8.33331ZM24.9999 32.9398V11.9599L24.8919 12.0061L14.9999 7.0601V28.0401L15.1079 27.9938L24.9999 32.9398Z" fill="#C0D749"/></svg></div><h2>Please select accurate shipping address</h2><p>For swift and precise delivery, we recommend to select the suggested shipping address.</p></div></div><div class="scroll-tanya-adrs-bg"><div class="scroll-tanya-adrs"><div class="form-check"><input class="form-check-input" type="radio" id="ship-address"><label class="form-check-label" for="defaultCheck43"><h4>Suggested address</h4><p>Suite 336 784 <span>Tanya Ports, Friesenbury</span>, NC 51587-5771</p></div></label></div><div class="tanya-open-adrs"><div class="form-check"><input class="form-check-input" type="radio" id="ship-address"><label class="form-check-label" for="defaultCheck44"><h4>Your typed address</h4><p class="entered-shipping-address">ABCDEFGHIJKLMNOPQRSTUVWXYZ</p></div></label></div></div><div class="adrs-buttons"><button type="button" class="tanya-close-btn " >Close</button><button type="button" class="tanya-close-btn save-changes">save changes</button></div></div></div></section>`;

var popupFormStyles = `
#popUpAddressForm{
    position: absolute;
    top: 270px;
    left: 601px;

}
#placeOrderButton{
    align-items: center;
    display: inline-flex;
    height: auto;
    justify-content: center;
    position: relative;
    text-align: center;
    transition: box-shadow .1s linear;
    background:red;
    color:#ffff;
    padding:15px 150px;
    border: 1px solid #0000;
    border-radius: 10px;    
}
.scroll-right-prompt-popUpform{
    border-radius: 20px;
    background: #FFF;
    text-align: center;
    max-width: 450px;
    margin: 0 auto;
}
.scroll-right-prompt-popUpform h5{
    color: #3B4A60;
    font-size: 20px;
    font-weight: 600;
}
.scroll-rshiping-adrs-bg{
    border-radius: 10px;
    background: #FFF;
    box-shadow: 0px 4px 40px 0px rgba(0, 0, 0, 0.12);
    padding: 32px;
    margin-top: 32px;
}
.sadr-accurate h2{
    color: #000;
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 0;
    padding: 10px 0;
}
.sadr-accurate p{
    color: #222;
    font-size: 14px;
    font-weight: 400;
    max-width: 365px;
    margin: 0 auto;
}
.scroll-tanya-adrs, .tanya-open-adrs{
    border-radius: 8px;
    background: #F5F5F5;
    padding: 32px 0;
    margin-top: 10px;
    position: relative;
}
.scroll-tanya-adrs p, .tanya-open-adrs p{
    color: #222;
    font-size: 14px;
    font-weight: 400;
    max-width: 194px;
    margin: 0 auto;
}
.scroll-tanya-adrs p span, .tanya-open-adrs p span{
    color: #AAC22F;
}
.scroll-tanya-adrs .tanya-adr-btn{
    border-radius: 8px;
    background: #3168B9;
    outline: none;
    color: #FFF;
    font-size: 16px;
    font-weight: 500;
    border: none;
    padding: 15px 24px;
    width: 206px;
    margin-top: 24px;
    position: relative;
    padding-left: 44px;
}
.scroll-tanya-adrs .tanya-adr-btn::after{
    position: absolute;
    content: url( https://wordpress-1078893-4208184.cloudwaysapps.com/wp-content/plugins/address-validator/assets/images/tick.svg);
    left: 18px;
    top: 17px;

}
.scroll-tanya-adrs h4, .tanya-open-adrs h4{
    color: #000;
    font-size: 17px;
    font-weight: 600;
}
.scroll-rshiping-adrs .sadr-accurate{
    padding-bottom: 22px;
}
.scroll-rshiping-adrs-bg .tanya-close-btn{
    border-radius: 8px;
    border: 1px solid #97B1D7;
    background: #FFF;
    outline: none;
    padding: 15px 32px;
    color: #3168B9;
    font-size: 16px;
    font-weight: 500;
    margin-top: 32px;
    margin-left: 20px;  
}


.scroll-tanya-adrs .form-check,
.tanya-open-adrs .form-check{
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: none;
}
.scroll-tanya-adrs .form-check input,
.tanya-open-adrs .form-check input{
  box-shadow: none;
}
`;


var styleElement = document.createElement('style');
styleElement.type = 'text/css';
if (styleElement.styleSheet) {
      // For IE
      styleElement.styleSheet.cssText = popupFormStyles;
} else {
      // For other browsers
      styleElement.appendChild(document.createTextNode(popupFormStyles));
}

// Append the style element to the document's head
 document.head.appendChild(styleElement);
// var addressContent = document.querySelector('.wc-block-components-address-card__address-section').innerText;
// console.log(addressContent);

document.addEventListener('DOMContentLoaded', function () {
    console.log("loader........");
    setTimeout(function () {
        console.log("loaded");
        var originalPlaceOrderButton = document.querySelector('.wc-block-components-checkout-place-order-button');
        if (originalPlaceOrderButton) {
           originalPlaceOrderButton.style.display = 'none';
        }
        var customButton = document.createElement('button');
        customButton.id = 'placeOrderButton';
        customButton.type = 'button';
        customButton.className = 'wc-block-place-order-button';
        customButton.innerText = 'Place Order';


          // Insert the custom button in the same position
        var actionsRow = document.querySelector('.wc-block-checkout__actions_row');
        if (actionsRow) {
            actionsRow.appendChild(customButton);
            // Add an event listener to your custom button
            customButton.addEventListener('click', function (e) {
                e.preventDefault();
                var address1 = document.getElementById('shipping-address_1').value;
                var address2 = document.getElementById('shipping-address_2').value;
                var country = document.getElementById('components-form-token-input-0').value;
                var city = document.getElementById('shipping-city').value;
                var state = document.getElementById('components-form-token-input-1').value;
                var postcode = document.getElementById('shipping-postcode').value;
                 // Format the shipping address
                var formattedAddress = `${address1}, ${address2}, ${city}, ${state} ${postcode}, ${country}`;
                console.log(formattedAddress);
        
                var popupForm = `<section id="popUpAddressForm"><div class="scroll-right-prompt-popUpform"><h5>Suggested corrected prompts</h5><div class="scroll-rshiping-adrs-bg"><div class="scroll-rshiping-adrs">
                <div class="sadr-accurate"><div><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none"><path d="M3.33325 8.33331L14.9999 3.33331L24.9999 8.33331L35.5049 3.83115C35.9281 3.64985 36.4179 3.8458 36.5993 4.26883C36.6436 4.37256 36.6666 4.48425 36.6666 4.5971V31.6666L24.9999 36.6666L14.9999 31.6666L4.49485 36.1688C4.07182 36.3501 3.58194 36.1541 3.40064 35.7311C3.35617 35.6275 3.33325 35.5156 3.33325 35.4028V8.33331ZM24.9999 32.9398V11.9599L24.8919 12.0061L14.9999 7.0601V28.0401L15.1079 27.9938L24.9999 32.9398Z" fill="#C0D749"/></svg></div><h2>Please select accurate shipping address</h2><p>For swift and precise delivery, we recommend to select the suggested shipping address.</p></div></div><div class="scroll-tanya-adrs-bg"><div class="scroll-tanya-adrs"><div class="form-check"><input class="form-check-input" type="radio" name="ship-address" id="defaultCheck43"><label class="form-check-label" for="defaultCheck43"><h4>Suggested address</h4><p>Suite 336 784 <span>Tanya Ports, Friesenbury</span>, NC 51587-5771</p></div></label></div><div class="tanya-open-adrs"><div class="form-check"><input class="form-check-input" type="radio" name="ship-address" id="defaultCheck44"><label class="form-check-label" for="defaultCheck44"><h4>Your typed address</h4><p class="entered-shipping-address">${formattedAddress}</p></div></label></div></div><div class="adrs-buttons"><button type="button" class="tanya-close-btn " >Close</button><button type="button" class="tanya-close-btn save-changes">save changes</button></div></div></div></section>`;

                  
                var popupContainer = document.createElement('div');
                popupContainer.innerHTML = popupForm;
                document.body.appendChild(popupContainer);
  
                popupContainer.querySelector('.tanya-close-btn').addEventListener('click', function () {
                    popupContainer.remove();
                    originalPlaceOrderButton.style.display = 'block';
                    customButton.style.display = 'none';
                    //document.querySelector('.wc-block-components-form ').submit();
                });
   
                popupContainer.querySelector('.tanya-close-btn.save-changes').addEventListener('click', function () {
                     
                     console.log("Save changes button clicked");
                     document.querySelector('.wc-block-components-form ').submit();
                    popupContainer.remove();
                });
            });
        }

   
    }, 1000);

});


  